package com.mizore.spring.test.bean;

public interface IUserService {

    void query();
}
