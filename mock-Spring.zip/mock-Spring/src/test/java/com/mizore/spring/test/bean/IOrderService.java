package com.mizore.spring.test.bean;

public interface IOrderService {

    String create(String orderId);

    String query();

    IUserService getUserService();
}
