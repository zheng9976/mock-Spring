package com.mizore.spring.test.bean;

public interface IUserDao {

    String queryUserName(String uId);
}
