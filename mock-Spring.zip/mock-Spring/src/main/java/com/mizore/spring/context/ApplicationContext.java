package com.mizore.spring.context;

import com.mizore.spring.beans.factory.ListableBeanFactory;

public interface ApplicationContext extends ListableBeanFactory, ApplicationEventPublisher{
}
