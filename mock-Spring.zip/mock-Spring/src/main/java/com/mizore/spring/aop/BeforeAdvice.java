package com.mizore.spring.aop;

import org.aopalliance.aop.Advice;

public interface BeforeAdvice extends Advice {
}
