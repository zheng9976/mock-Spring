package com.mizore.spring.beans.factory;

public interface HierarchicalBeanFactory extends BeanFactory{
}
