package com.mizore.spring.util;

public interface StringValueResolver {
    String resolveStringValue(String strVal);
}
