package com.mizore.spring.core.io;

public interface ResourceLoader {

    Resource getResource(String location);
}
